# 电液转向系统质量性能评估与预测综合报告

- 生成时间：2026-10-13 15:07:17
- 工程名称：D4完整流程验收工程
- 正式机械模型：`ENGINEERING_STEERING_MODEL`
- 正式液压模型：`ENGINEERING_HYDRAULIC_V1`

## 1. 任务输入说明

- 任务谱：`E:\15_project\data\degradation\task_spectrum_30day_example.csv`
- 初始状态：`d1_day30`

## 2. 机械—液压—控制联合仿真

- 计算完成：True
- 液压跟踪达标：True
- 目标轨迹可行：True
- 动态计算耗时：4.263 s

## 3. 关键部件退化结果

- 对象：2台齿轮泵、4个转向阀、4组等效液压缸。
- 模式：泵内泄漏/机械损失、阀内泄漏/响应迟滞、缸内泄漏/摩擦增长。
- 工况风险条数：30
- 标记：`ENGINEERING_DESIGN_ASSUMPTION / PENDING_CLIENT_CALIBRATION`

## 4. 当前质量评价

- 整车质量等级：`HEALTHY`
- 场景性质：自然/检查点状态
- 指标来自D2标准工况真实22状态动态仿真。

## 5. 未来任务循环质量变化

- 首个真实动力学检查点等级：`HEALTHY`
- 寿命临界检查点等级：`DEGRADED`
- 等级来自D2真实22状态检查点；循环间退化由D3快速模型推进。

## 6. 剩余任务循环结果

- 预测状态：`FAILURE_REACHED`
- 剩余完整30天任务：130
- 首次越限任务循环：131
- 首次越限工况段：D07-S07-停车左大角
- 限制部件：前通道转向阀
- 原因：前通道转向阀:响应迟滞：损伤 0.900032 ≥ 硬限值 0.9
- 循环内记录时刻是工况段末首次越限检测时刻，不是段内精确失效瞬间。
- Monte Carlo为快速近似载荷推进，并非每条随机路径都执行完整22状态验证。

## 8. 工况风险与适用边界

- 高速大转角可能超出附着极限；该风险与液压退化故障分开。
- 退化率、质量阈值、硬失效阈值和随机分布均待甲方试验标定。
- 当前结果用于工程趋势、接口和物理反馈验证，不是实车认证寿命。

## 9. 可追溯信息

```json
{
  "mechanical_model": "ENGINEERING_STEERING_MODEL",
  "hydraulic_model": "ENGINEERING_HYDRAULIC_V1",
  "healthy_parameters_sha256": "9720085e65c4af961bca81305e3bd088e6bad6093141dc6de56bef41b9b5cdcc",
  "d1_config_sha256": "2c8f89c6a6321dc6296c703b7830a3a7824d73e4e7271b2376da605a9c9dbe4f",
  "d2_config_sha256": "f283ae5bd91cf82eaae6032d3c2d14de10619d0509a1352c3cea3f93aa234f7d",
  "d3_config_sha256": "ad97e3cea854d5d5f399e64fe26bd2d5d4a2e282cff80f39fbb72ee71a193a40",
  "created_at": "2026-10-13 15:07:17",
  "spectrum_sha256": "706f72273506e1453636cdc6d338d236aa954054ed4607d1e3c43d4a2ea86ec8"
}
```
