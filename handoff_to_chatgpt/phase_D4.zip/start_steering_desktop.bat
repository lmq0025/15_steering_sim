@echo off
setlocal
set "APP_ROOT=%~dp0"
set "PYTHON_EXE=E:\ProgramData\condaData\envs_dirs\steering_sim\python.exe"
if not exist "%PYTHON_EXE%" (
  echo [错误] 未找到指定 Python：%PYTHON_EXE%
  echo 请确认 steering_sim 环境安装位置。
  pause
  exit /b 2
)
cd /d "%APP_ROOT%"
set "PYTHONPATH=%APP_ROOT%src;%APP_ROOT%"
set "MPLBACKEND=Agg"
"%PYTHON_EXE%" -m steering_sim.desktop --maximized
if errorlevel 1 (
  echo.
  echo [错误] 电液转向预测软件启动失败，错误码 %errorlevel%。
  echo 请运行 scripts\d4\check_desktop_environment.py 查看依赖诊断。
  pause
)
endlocal
