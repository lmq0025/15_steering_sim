"""PHASE D1：任务谱驱动的部件级确定性退化预测。"""

from .damage import (ComponentDamageState, DegradationModelConfig,
                     DegradationState, load_degradation_config)
from .prediction import D1Prediction, D1Predictor
from .spectrum import (SpectrumError, TaskSegment, TaskSpectrum,
                       load_task_spectrum)

__all__ = [
    "ComponentDamageState", "D1Prediction", "D1Predictor",
    "DegradationModelConfig", "DegradationState", "SpectrumError",
    "TaskSegment", "TaskSpectrum", "load_degradation_config",
    "load_task_spectrum",
]
