# PHASE D2 reproduction

```powershell
E:\ProgramData\condaData\envs_dirs\steering_sim\python.exe scripts\d2\run_phase_d2.py
E:\ProgramData\condaData\envs_dirs\steering_sim\python.exe -m pytest tests\quality_assessment tests\degradation -q
```

D2 stops before RUL/Gamma Monte Carlo and does not modify the GUI.
