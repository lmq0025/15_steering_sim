# PHASE D1 复现

在 `E:\15_project` 使用唯一 Python：

```powershell
E:\ProgramData\condaData\envs_dirs\steering_sim\python.exe scripts\d1\run_phase_d1.py
E:\ProgramData\condaData\envs_dirs\steering_sim\python.exe -m pytest tests\degradation -q
```

完整回归与打包：

```powershell
E:\ProgramData\condaData\envs_dirs\steering_sim\python.exe -m pytest -q
E:\ProgramData\condaData\envs_dirs\steering_sim\python.exe scripts\d1\run_phase_d1.py --package
```

退化配置全部为 `ENGINEERING_DESIGN_ASSUMPTION`，尚待甲方标定。
