from __future__ import annotations

from dataclasses import dataclass
import math

from .parameters import ChannelParameters
from .valve import ValveFlows, four_way_flows, opening


@dataclass(frozen=True)
class SupplySolution:
    pressure: float
    relief_flow: float
    valve_flows: ValveFlows


def relief_flow(pressure: float, cracking_pressure: float, conductance: float) -> float:
    return conductance * max(pressure - cracking_pressure, 0.0)


def solve_supply(q_pump: float, command: float, p_a: float, p_b: float,
                 p: ChannelParameters) -> SupplySolution:
    # The active supply metering edge is one square-root restriction in parallel
    # with the relief path.  Substitution y=sqrt(ps-p_chamber) gives a quadratic,
    # avoiding an iterative algebraic solve in the simulation loop.
    g = p.supply.relief_conductance
    r = p.supply.path_resistance
    reff = r + 1.0 / g
    area = opening(command, p.valve)
    chamber = p_a if command >= 0.0 else p_b
    k = p.valve.discharge_coefficient * area * math.sqrt(2.0 / p.fluid.density)
    q_at_crack = k * math.sqrt(max(p.supply.relief_cracking_pressure - chamber, 0.0))
    if k > 0.0 and q_pump <= q_at_crack:
        ps = chamber + (q_pump / k) ** 2
        qr = 0.0
    elif k == 0.0:
        qr = max(q_pump, 0.0)
        ps = p.supply.relief_cracking_pressure + reff * qr
    else:
        # y^2 + reff*k*y + chamber-pcrack-reff*qp = 0
        b = reff * k
        c = chamber - p.supply.relief_cracking_pressure - reff * q_pump
        y = max(0.0, 0.5 * (-b + math.sqrt(max(b * b - 4.0 * c, 0.0))))
        ps = chamber + y * y
        qr = max((ps - p.supply.relief_cracking_pressure) / reff, 0.0)
    vf = four_way_flows(command, ps, p.supply.tank_pressure, p_a, p_b, p.valve, p.fluid)
    return SupplySolution(ps, qr, vf)
